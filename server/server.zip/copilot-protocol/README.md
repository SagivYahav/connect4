# Connect Four – Node.js + Vite

## Overview
This project implements the Connect Four game with:
- **Server**: Node.js (WebSocket server + game logic).
- **Client**: Vite Vanilla (HTML + Canvas + WebSocket).
- **Database**: MySQL with connection pool (board state snapshot saved later).

## Folder Structure
```
connect-four/
├─ client/       # Frontend (Vite Vanilla)
│  ├─ index.html
│  └─ main.js
├─ server/       # Backend (Node.js)
│  └─ index.js
├─ CONTEXT.md    # Rules and constraints
├─ WS_PROTOCOL.md # WebSocket message protocol
└─ README.md
```

## How to Run Locally
1. **Client**
   ```bash
   cd client
   npm create vite@latest . --template vanilla
   npm install
   npm run dev
   ```
   The client runs by default on http://localhost:5173

2. **Server**
   ```bash
   cd server
   npm init -y
   npm install ws mysql
   node index.js
   ```
   The server listens on port 3000 (WebSocket).

3. **Test**
   Open two browser tabs on http://localhost:5173
   - Player 1: create a room (roomCode "new").
   - Player 2: join with the same roomCode.
   - Both can now play against each other.

## Notes
- All gameplay logic runs **only on the server**.
- The client only handles UI rendering and sending moves.
- MySQL will be integrated later to save the current board state.
- Follow `CONTEXT.md` and `WS_PROTOCOL.md` strictly.
