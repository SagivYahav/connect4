# WebSocket Protocol – Connect Four

## Client → Server
- `hello` { name, color, roomCode | "new" }
- `move` { col }
- `resign` {}

## Server → Client
- `room_status` { status: "waiting" | "ready" | "full", roomCode }
- `start` { you: "P1"|"P2", next: "P1"|"P2", board }
- `state` { board, next, lastMove: { row, col, by } }
- `game_over` { result: "win"|"loss"|"draw", line?: [{r,c},...] }
- `opponent_left` {}
- `error` { reason }
