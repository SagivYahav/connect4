# Connect Four Project – Context & Rules

## General Rules
- **Server**: Node.js only (no Express or other libraries not taught in class).
- **Client**: Vite Vanilla.
- **Communication**: WebSockets for each player.
- **Scope**:
  - The server must handle multiple games simultaneously.
  - Each game has exactly 2 players.
  - No scoring/leaderboards/statistics required – only the current board state.
  - The server runs locally only (not accessible from other machines).
- **MySQL**:
  - Use a connection pool (as taught in class).
  - Later, save the current board state in SQL **in addition** to in-memory.
- **Coding Rules**:
  - Do not add external libraries or commands that were not taught in the course.
  - Code must remain clear and simple.
  - All game logic (turns, win check, draw check) must run **only on the server**.
  - The client only renders and sends actions.

## Folder Structure (minimal version)
```
connect-four/
├─ client/
│  ├─ index.html   # Basic HTML (form + canvas)
│  └─ main.js      # WebSocket + UI + rendering
├─ server/
│  └─ index.js     # WebSocket server + rooms + game logic
├─ CONTEXT.md
├─ WS_PROTOCOL.md
└─ README.md
```

## Workflow
1. Start with WebSocket basics – connect, disconnect, send/receive messages.
2. Add room management (2 players only).
3. Add game logic (in-memory board).
4. Connect client UI.
5. Only at the end – add MySQL board snapshots.
